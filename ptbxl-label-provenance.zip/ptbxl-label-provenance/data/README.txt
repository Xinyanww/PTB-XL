Place ptbxl_database.csv and scp_statements.csv here.
